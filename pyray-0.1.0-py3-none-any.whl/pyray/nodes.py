"""
Riverbed Stingray Nodes
"""
from .base import Resource
from pyray import exceptions